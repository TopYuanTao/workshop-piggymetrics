cd /data/account-service
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/auth-service
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/config
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/gateway
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/monitoring
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/notification-service
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/registry
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/statistics-service
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
cd /data/zipkin
mvn clean
mvn package -Dmaven.test.skip=true
mvn clean
#---------------
